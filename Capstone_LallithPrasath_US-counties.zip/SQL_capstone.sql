use capstone;

--create table SRC_COVID(
--[Date] date,
--county varchar(20),
--[state] varchar(20),
--FIPS integer,
--cases integer,
--deaths integer)

--drop table SRC_COVID

--create table STG_COVID(
--[Date] date,
--county varchar(20),
--[state] varchar(20),
--FIPS integer,
--cases integer,
--deaths integer)

--create table STG_COVID_REJECT(
--[Date] date,
--county varchar(20),
--[state] varchar(20),
--FIPS integer,
--cases integer,
--deaths integer)

--create table DIM_DATE(
--Date_ID integer primary key,
--[Date] Date,
--[Year] integer,
--[Quarter] integer,
--[Month] integer,
--[Day] integer,
--[Weekday] integer
--)
--alter table DIM_DATE add create_date nvarchar(19), update_date nvarchar(19)

--create table DIM_REGION(
--Region_ID integer Primary Key,
--county varchar(20),
--county_code integer,
--[State] varchar(20),
--state_code integer,
--FIPS integer)
--alter table DIM_REGION add create_date datetime, update_date datetime

--select * from DIM_DATE
--select * from DIM_REGION


--create table FACT_COVID(
--Covid_ID integer primary key,
--Date_ID integer,
--Region_ID integer,
--cases integer,
--deaths integer,
--foreign key (Date_ID) references DIM_DATE(Date_ID),
--foreign key (Region_ID) references DIM_REGION(Region_ID)
--)
--alter table FACT_COVID add create_date datetime,update_date datetime

--Select * from STG_COVID
--select * from FACT_COVID


--Insights--

-- max cases in states
SELECT TOP 10 dr.State, MAX(fc.cases) as TotalCases, MAX(fc.deaths) as TotalDeaths
FROM FACT_COVID fc
JOIN DIM_REGION dr on fc.Region_ID = dr.Region_ID
GROUP BY state
ORDER BY TotalCases DESC;

-- Max deaths in counties--
SELECT TOP 10 dr.county, MAX(fc.cases) as TotalCases, MAX(fc.deaths) as TotalDeaths
FROM FACT_COVID fc
JOIN DIM_REGION dr on fc.Region_ID = dr.Region_ID
GROUP BY county
ORDER BY TotalDeaths DESC;

--cases in California--
WITH CumulativeData AS (
    SELECT 
        dd.date,
        SUM(fc.cases) OVER (ORDER BY dd.Date) AS CumulativeCases,
        SUM(fc.deaths) OVER (ORDER BY dd.Date) AS TotalDeaths
    FROM FACT_COVID fc
    JOIN DIM_DATE dd ON fc.Date_ID = dd.Date_ID
    JOIN DIM_REGION dr ON fc.Region_ID = dr.Region_ID
    WHERE 
        state = 'California'
),DailyData AS (
	SELECT 
		date,
		CumulativeCases - COALESCE(LAG(CumulativeCases) OVER (ORDER BY date), 0) AS DailyCases,
		TotalDeaths - COALESCE(LAG(TotalDeaths) OVER (ORDER BY date), 0) AS DailyDeaths
	FROM 
		CumulativeData
)
SELECT 
    date, DailyCases, DailyDeaths
FROM 
    DailyData
WHERE 
    DailyCases > 0 OR DailyDeaths > 0
ORDER BY 
    date;

-- cases per month--
WITH LastDayOfMonth AS (
    SELECT dd.Date,fc.cases,fc.deaths
    FROM FACT_COVID fc
    JOIN DIM_DATE dd ON fc.Date_ID = dd.Date_ID
    WHERE 
        date = EOMONTH(date) 
),
SummedCases AS (
    SELECT 
        FORMAT(date, 'yyyy-MM') AS month,
        SUM(cases) AS total_cases,
		sum(deaths) AS total_deaths
    FROM 
        LastDayOfMonth
    GROUP BY 
        FORMAT(date, 'yyyy-MM') -- Group by month
)
SELECT month, total_cases, total_deaths
FROM SummedCases
ORDER BY month;


-- moving average of cases and deaths--
WITH  DailyIncrease AS (
    SELECT 
        dd.Date,
        SUM(fc.cases) AS total_cases,
        SUM(fc.deaths) AS total_deaths
    FROM FACT_COVID fc
    JOIN DIM_DATE dd ON fc.Date_ID = dd.Date_ID
    GROUP BY 
        date
),
DailyIncreaseCalculated AS (
    SELECT 
        date,
        total_cases - COALESCE(LAG(total_cases) OVER (ORDER BY date), 0) AS daily_cases,
        total_deaths - COALESCE(LAG(total_deaths) OVER (ORDER BY date), 0) AS daily_deaths
    FROM 
        DailyIncrease
),
MovingAverage AS (
    SELECT 
        date,
        AVG(daily_cases) OVER (ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS avg_daily_cases,
        AVG(daily_deaths) OVER (ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS avg_daily_deaths
    FROM 
        DailyIncreaseCalculated
)
SELECT TOP 396
    date,
    avg_daily_cases,
    avg_daily_deaths
FROM 
    MovingAverage
WHERE 
    date >= (SELECT MIN(date) FROM DIM_DATE) 
ORDER BY 
    date;

-------------------------------------------------------

select * from STG_COVID
select * from FACT_COVID
select * from DIM_DATE
select * from DIM_REGION

delete from FACT_COVID
delete from DIM_REGION
delete from DIM_DATE
delete from STG_COVID
delete from STG_COVID_REJECT

-------------------------------------------

--joining tables on the fact table--

select dd.[Date], dr.county, dr.State, dr.FIPS, fc.cases,fc.deaths from FACT_COVID fc
join DIM_DATE dd on fc.Date_ID = dd.Date_ID
join DIM_REGION dr on fc.Region_ID = dr.Region_ID




